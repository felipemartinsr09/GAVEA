document.addEventListener('DOMContentLoaded', () => {
    const loginButton = document.getElementById('login-button');
    loginButton.addEventListener('click', () => {
        const emailDigitado = document.getElementById('email-input').value;
        const senhaDigitada = document.getElementById('senha-input').value;

        fetch('http://localhost:8080/api/auth/login', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                email: emailDigitado,
                senha: senhaDigitada,
            })
        })
        .then(response => {
            if (response.ok) {
                return response.json(); 
            } else {
                alert("E-mail ou senha incorretos!");
                throw new Error('Falha no login');
            }
        })
        .then(usuario => {
            console.log("Login feito com sucesso:", usuario);
            alert("Bem-vindo, " + usuario.nomeUsuario); 
        })
        .catch(error => {
            console.error('Erro ao tentar fazer login:', error);
        });
    });
});